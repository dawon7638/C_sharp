namespace view_models_fun.Models
{
    public class UserModel
    {
        public string Name { get; set; }
    }
}