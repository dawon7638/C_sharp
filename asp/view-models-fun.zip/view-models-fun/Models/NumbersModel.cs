namespace view_models_fun.Models
{
    public class NumbersModel
    {
        public int Numbers {get; set;}
    }
}