namespace view_models_fun.Models
{
    public class UsersModel
    {
        public string ListofUsers { get; set; }
    }
}