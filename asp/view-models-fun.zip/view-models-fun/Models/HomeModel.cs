namespace view_models_fun.Models
{
    public class HomeModel
    {
        public string Paragraph { get; set; }
    }
}