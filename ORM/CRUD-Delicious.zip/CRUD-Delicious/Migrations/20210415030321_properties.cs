﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CRUD_Delicious.Migrations
{
    public partial class properties : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
