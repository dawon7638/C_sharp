﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ActivityCtr.Migrations
{
    public partial class fixedDuration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
