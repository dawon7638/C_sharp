﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BankAccts.Migrations
{
    public partial class fixedTransProperty : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
